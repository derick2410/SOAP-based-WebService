/*
 * (C) Derick Augustine Coutinho
 * This file is copyright to Derick.
 */
package edu.gmu.sessionws;

import edu.gmu.csd.bean.StudentDetail;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import org.apache.commons.lang3.StringUtils;

/**
 * Class is used as a web service to call the DB using JPA.
 *
 * @author Derick Augustine Coutinho
 * @since 05/02/2015
 * @version 0.1
 */
@Stateless
@LocalBean
@WebService(serviceName = "StudentSurveySessionBeanWS")
public class StudentSurveySessionBeanWS {

    @PersistenceContext(unitName = "STUDENT_SURVEY_PU")
    private EntityManager entityManager;

    /**
     * Method is used to save the student survey details entered by the user in
     * the DB.
     *
     * @param studentDetail - StudentDetail
     * @return boolean
     */
    @WebMethod(operationName = "saveStudentSurveyInfo")
    public boolean saveStudentSurveyInfo(@WebParam(partName = "studentDetail") StudentDetail studentDetail) {
        Studsurveyinfo studsurveyinfo = new Studsurveyinfo();

        studsurveyinfo.setFirstname(studentDetail.getFirstname());
        studsurveyinfo.setLastname(studentDetail.getLastname());
        studsurveyinfo.setStreetaddress(studentDetail.getStreetaddress());
        studsurveyinfo.setZipcode(studentDetail.getZipcode());
        studsurveyinfo.setCity(studentDetail.getCity());
        studsurveyinfo.setSstate(studentDetail.getSstate());
        studsurveyinfo.setTelnum(studentDetail.getTelnum());
        studsurveyinfo.setEmail(studentDetail.getEmail());
        studsurveyinfo.setSurveydate(studentDetail.getSurveydate());
        studsurveyinfo.setInterest(studentDetail.getInterest());
        studsurveyinfo.setRecomend(studentDetail.getRecomend());

        StringBuilder like = new StringBuilder();
        for (String campusLikeVal : studentDetail.getCampusLike()) {
            like.append(campusLikeVal);
            like.append(" ");
        }
        studsurveyinfo.setLikings(like.toString());

        List<Emergencycontactinfo> emergencycontactinfos = new ArrayList<Emergencycontactinfo>();
        Emergencycontactinfo emergencycontactinfo = new Emergencycontactinfo();
        emergencycontactinfo.setEcontactname(studentDetail.getEname1());
        emergencycontactinfo.setEcontactphone(studentDetail.getEtel1());
        emergencycontactinfo.setEcontactmail(studentDetail.getEtel1());
        emergencycontactinfos.add(emergencycontactinfo);

        if (StringUtils.isNotEmpty(studentDetail.getEemail2())) {
            emergencycontactinfo = new Emergencycontactinfo();
            emergencycontactinfo.setEcontactname(studentDetail.getEname2());
            emergencycontactinfo.setEcontactphone(studentDetail.getEtel2());
            emergencycontactinfo.setEcontactmail(studentDetail.getEemail2());
            emergencycontactinfos.add(emergencycontactinfo);
        }

        studsurveyinfo.setEmergencycontactinfoList(emergencycontactinfos);
        try {
            persist(studsurveyinfo);
        } catch (Exception excp) {
            return false;
        }
        return true;
    }

    /**
     * Method is used to retrieve all the list of student survey details from
     * the DB.
     *
     * @return List<StudentDetail>
     */
    @WebMethod(operationName = "retrieveStudentSurveyInfo")
    public List<StudentDetail> retrieveStudentSurveyInfo() {
        TypedQuery<Studsurveyinfo> studentListQuery = entityManager.createNamedQuery("Studsurveyinfo.findAll", Studsurveyinfo.class);
        return setStudentSurveyDetails(studentListQuery.getResultList());
    }

    /**
     * Method is used to retrieve the particular data searched by the user.
     *
     * @param studentDetail - StudentDetail
     * @return List<StudentDetail>
     */
    @WebMethod(operationName = "searchStudentSurveyInfo")
    public List<StudentDetail> searchStudentSurveyInfo(@WebParam(partName = "studentDetail") StudentDetail studentDetail) {
        Query query = entityManager.createQuery("SELECT s from Studsurveyinfo s WHERE s.firstname LIKE :first_name OR s.lastname LIKE :last_name OR s.sstate LIKE :state OR s.city LIKE :city ORDER BY s.lastname ASC");

        String firstName = StringUtils.EMPTY;
        String lastName = StringUtils.EMPTY;
        String city = StringUtils.EMPTY;
        String state = StringUtils.EMPTY;
        if (!StringUtils.EMPTY.equalsIgnoreCase(studentDetail.getFirstname())) {
            firstName = studentDetail.getFirstname() + "%";
        }
        if (!StringUtils.EMPTY.equalsIgnoreCase(studentDetail.getLastname())) {
            lastName = studentDetail.getLastname() + "%";
        }
        if (!StringUtils.EMPTY.equalsIgnoreCase(studentDetail.getCity())) {
            city = studentDetail.getCity() + "%";
        }
        if (!StringUtils.EMPTY.equalsIgnoreCase(studentDetail.getSstate())) {
            state = studentDetail.getSstate() + "%";
        }

        query.setParameter("first_name", firstName);
        query.setParameter("last_name", lastName);
        query.setParameter("city", city);
        query.setParameter("state", state);

        return setStudentSurveyDetails(query.getResultList());
    }

    /**
     * Method is used to delete the data from the DB.
     *
     * @param studentId - long
     * @return boolean
     */
    @WebMethod(operationName = "deleteStudentSurveyInfo")
    public boolean deleteStudentSurveyInfo(@WebParam(partName = "studentId") long studentId) {
        try {
            Studsurveyinfo studsurveyinfo = entityManager.find(Studsurveyinfo.class, studentId);
            entityManager.remove(studsurveyinfo);
        } catch (Exception ex) {
            return false;
        }
        return true;
    }

    /**
     * Method is used to persist the object in the DB.
     *
     * @param object - Object
     */
    public void persist(Object object) {
        entityManager.persist(object);
    }

    /**
     * Method is used to set the StudentDetail bean from the Studsurveyinfo
     * entity class.
     *
     * @param studsurveyinfos - List<Studsurveyinfo>
     * @return studentDetailsList - List<StudentDetail>
     */
    private List<StudentDetail> setStudentSurveyDetails(List<Studsurveyinfo> studsurveyinfos) {
        List<StudentDetail> studentDetailsList = new ArrayList<StudentDetail>();
        StudentDetail studentDetail;

        if (null != studsurveyinfos) {
            for (Studsurveyinfo studsurveyinfo : studsurveyinfos) {
                studentDetail = new StudentDetail();

                studentDetail.setStudentid(studsurveyinfo.getStudentid());
                studentDetail.setFirstname(studsurveyinfo.getFirstname());
                studentDetail.setLastname(studsurveyinfo.getLastname());
                studentDetail.setStreetaddress(studsurveyinfo.getStreetaddress());
                studentDetail.setZipcode(studsurveyinfo.getZipcode());
                studentDetail.setCity(studsurveyinfo.getCity());
                studentDetail.setSstate(studsurveyinfo.getSstate());
                studentDetail.setTelnum(studsurveyinfo.getTelnum());
                studentDetail.setEmail(studsurveyinfo.getEmail());
                studentDetail.setTelnum(studsurveyinfo.getTelnum());
                studentDetail.setLikings(studsurveyinfo.getLikings());
                studentDetail.setInterest(studsurveyinfo.getInterest());
                studentDetail.setRecomend(studsurveyinfo.getRecomend());

                if (null != studsurveyinfo.getEmergencycontactinfoList()) {
                    int count = 0;
                    for (Emergencycontactinfo emergencycontactinfo : studsurveyinfo.getEmergencycontactinfoList()) {
                        if (count == 0) {
                            studentDetail.setEname1(emergencycontactinfo.getEcontactname());
                            studentDetail.setEtel1(emergencycontactinfo.getEcontactphone());
                            studentDetail.setEemail1(emergencycontactinfo.getEcontactmail());
                        } else {
                            studentDetail.setEname2(emergencycontactinfo.getEcontactname());
                            studentDetail.setEtel2(emergencycontactinfo.getEcontactphone());
                            studentDetail.setEemail2(emergencycontactinfo.getEcontactmail());
                        }
                        count = 1;
                    }
                }

                studentDetailsList.add(studentDetail);
            }
        }

        return studentDetailsList;
    }
}
