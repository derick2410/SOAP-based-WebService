/*
 * (C) Derick Augustine Coutinho
 * This file is copyright to Derick.
 */
package edu.gmu.managed;

import edu.gmu.csd.bean.StudentDetail;
import edu.gmu.csd.bean.WinningResult;
import edu.gmu.csd.processor.DataProcessor;
import edu.gmu.sessionws.StudentSurveySessionBeanWS;
import edu.gmu.sessionws.StudentSurveySessionBeanWS_Service;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.xml.ws.WebServiceRef;
import org.apache.commons.lang3.StringUtils;

/**
 * Class is used as a Managed Bean to be used in various functionalities.
 *
 * @author Derick Augustine Coutinho
 * @since 05/02/2015
 * @version 0.1
 */
@ManagedBean(name = "studentSurvey")
@SessionScoped
public class StudentSurveyManagedBean {
    
    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/52.5.119.128/SWE645_CSD_EJB_JPA_JSF_WS-ejb/StudentSurveySessionBeanWS/StudentSurveySessionBeanWS.wsdl")
    private StudentSurveySessionBeanWS_Service service;
    
    private StudentDetail studentDetail = new StudentDetail();
    private WinningResult winningResult;
    private List<StudentDetail> studentDetailsList;

    /**
     * Method is used to reset the session and redirect to the specified page.
     *
     * @param nextPage - String
     * @return nextPage - String
     */
    public String resetSessionNRedirect(String nextPage) {
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("studentSurvey", null);
        
        return nextPage;
    }

    /**
     * Method is used to save the student survey details into the DB.
     *
     * @return fwdToXhtml - String
     */
    public String saveStudentSurveyInfo() {
        String fwdToXhtml;
        
        StudentSurveySessionBeanWS beanWS_Service = service.getStudentSurveySessionBeanWSPort();
        boolean isSaveSuccess = beanWS_Service.saveStudentSurveyInfo(setGetWSStudentDetails());
        
        if (isSaveSuccess) {
            WinningResult result = DataProcessor.calculateMeanStandardDeviation(studentDetail.getRaffle());
            setWinningResult(result);
            
            if (null != result && result.getMean() > 90) {
                // WinnerAcknowledgement JSP
                fwdToXhtml = "winnerAcknowledgement";
            } else {
                // SimpleAcknowledgement JSP
                fwdToXhtml = "simpleAcknowledgement";
            }
        } else {
            fwdToXhtml = "errorPage";
        }
        
        return fwdToXhtml;
    }

    /**
     * Method is used to retrieve the student survey information from the DB.
     *
     * @return List<StudentDetail>
     */
    public List<StudentDetail> retireveStudentSurveyInfo() {
        StudentSurveySessionBeanWS beanWS_Service = service.getStudentSurveySessionBeanWSPort();
        return setGetBeanStudentSurveyList(beanWS_Service.retrieveStudentSurveyInfo());
    }

    /**
     * Method is used to search a particular student survey details from the DB.
     *
     * @return String
     */
    public String searchStudentSurveyInfo() {
        StudentSurveySessionBeanWS beanWS_Service = service.getStudentSurveySessionBeanWSPort();
        setStudentDetailsList(setGetBeanStudentSurveyList(beanWS_Service.searchStudentSurveyInfo(setGetWSStudentDetails())));
        
        return "searchStudentSurvey";
    }

    /**
     * Method is used to delete the specific student survey detail from the
     * database.
     *
     * @param studentId - long
     * @param isSearch - String
     *
     * @return fwdToXhtml - String
     */
    public String deleteStudentSurveyInfo(long studentId, String isSearch) {
        StudentSurveySessionBeanWS beanWS_Service = service.getStudentSurveySessionBeanWSPort();
        String fwdToXhtml = null;
        if (!beanWS_Service.deleteStudentSurveyInfo(studentId)) {
            fwdToXhtml = "errorPage";
        } else {
            if (StringUtils.equalsIgnoreCase("YES", isSearch)) {
                searchStudentSurveyInfo();
            } else {
                retireveStudentSurveyInfo();
            }
        }
        
        return fwdToXhtml;
    }

    /**
     * Method to set and return the different object of student detail.
     *
     * @return wsStudentDetail - edu.gmu.sessionws.StudentDetail
     */
    private edu.gmu.sessionws.StudentDetail setGetWSStudentDetails() {
        edu.gmu.sessionws.StudentDetail wsStudentDetail = new edu.gmu.sessionws.StudentDetail();
        wsStudentDetail.setFirstname(studentDetail.getFirstname());
        wsStudentDetail.setLastname(studentDetail.getLastname());
        wsStudentDetail.setStreetaddress(studentDetail.getStreetaddress());
        wsStudentDetail.setCity(studentDetail.getCity());
        wsStudentDetail.setSstate(studentDetail.getSstate());
        wsStudentDetail.setZipcode(studentDetail.getZipcode());
        wsStudentDetail.setTelnum(studentDetail.getTelnum());
        wsStudentDetail.setSurveydate(studentDetail.getSurveydate());
        wsStudentDetail.setInterest(studentDetail.getInterest());
        wsStudentDetail.setRecomend(studentDetail.getRecomend());
        wsStudentDetail.setEname1(studentDetail.getEname1());
        wsStudentDetail.setEemail1(studentDetail.getEemail1());
        wsStudentDetail.setEtel1(studentDetail.getEtel1());
        wsStudentDetail.setEname2(studentDetail.getEname2());
        wsStudentDetail.setEemail2(studentDetail.getEemail2());
        wsStudentDetail.setEtel2(studentDetail.getEtel2());
        
        return wsStudentDetail;
    }

    /**
     * Method is used to convert the WS Student Bean's list to current projects
     * bean's list.
     *
     * @param wsStudentDetail - edu.gmu.sessionws.StudentDetail
     * @return studentDetailsListFromWS - List<StudentDetail>
     */
    private List<StudentDetail> setGetBeanStudentSurveyList(List<edu.gmu.sessionws.StudentDetail> wsStudentDetailList) {
        List<StudentDetail> studentDetailsListFromWS = new ArrayList<StudentDetail>();
        
        for (edu.gmu.sessionws.StudentDetail wsStudentDetail : wsStudentDetailList) {
            StudentDetail studDetail = new StudentDetail();
            studDetail.setStudentid(wsStudentDetail.getStudentid());
            studDetail.setFirstname(wsStudentDetail.getFirstname());
            studDetail.setLastname(wsStudentDetail.getLastname());
            studDetail.setStreetaddress(wsStudentDetail.getStreetaddress());
            studDetail.setCity(wsStudentDetail.getCity());
            studDetail.setSstate(wsStudentDetail.getSstate());
            studDetail.setZipcode(wsStudentDetail.getZipcode());
            studDetail.setTelnum(wsStudentDetail.getTelnum());
            studDetail.setSurveydate(wsStudentDetail.getSurveydate());
            studDetail.setInterest(wsStudentDetail.getInterest());
            studDetail.setRecomend(wsStudentDetail.getRecomend());
            studDetail.setEname1(wsStudentDetail.getEname1());
            studDetail.setEemail1(wsStudentDetail.getEemail1());
            studDetail.setEtel1(wsStudentDetail.getEtel1());
            studDetail.setEname2(wsStudentDetail.getEname2());
            studDetail.setEemail2(wsStudentDetail.getEemail2());
            studDetail.setEtel2(wsStudentDetail.getEtel2());
            
            studentDetailsListFromWS.add(studDetail);
        }
        
        return studentDetailsListFromWS;
    }
    
    public void setStudentDetail(StudentDetail studentDetail) {
        this.studentDetail = studentDetail;
    }
    
    public StudentDetail getStudentDetail() {
        return studentDetail;
    }
    
    public void setWinningResult(WinningResult winningResult) {
        this.winningResult = winningResult;
    }
    
    public WinningResult getWinningResult() {
        return winningResult;
    }
    
    public void setStudentDetailsList(List<StudentDetail> studentDetailsList) {
        this.studentDetailsList = studentDetailsList;
    }
    
    public List<StudentDetail> getStudentDetailsList() {
        return studentDetailsList;
    }
}
