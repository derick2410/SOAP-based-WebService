/*
 * (C) Derick Augustine Coutinho
 * This file is copyright to Derick.
 */
package edu.gmu.csd.processor;

import edu.gmu.csd.bean.WinningResult;
import org.apache.commons.lang3.StringUtils;

/**
 * Class is used as a Utility class to be used to perform various processing.
 *
 * @author Derick Augustine Coutinho
 * @since 05/02/2015
 * @version 0.1
 */
public class DataProcessor {

    /**
     * Method is used to calculate the mean standard deviation of the raffle
     * entered by the user.
     *
     * @param raffle
     * @return WinningResult
     */
    public static WinningResult calculateMeanStandardDeviation(String raffle) {
        String[] dataFieldsArr = null;
        if (StringUtils.isNotEmpty(raffle)) {
            dataFieldsArr = StringUtils.split(raffle, ",");
        }
        WinningResult winningResult = null;

        if (null != dataFieldsArr) {
            double mean;
            double sum = 0;
            double squareSum = 0;
            double stndrdDeviation;

            // First for loop to calculate the mean.
            for (String meanData : dataFieldsArr) {
                sum = sum + Integer.parseInt(meanData);
            }

            mean = sum / dataFieldsArr.length;

            // Second for loop to calculate the standard deviation.
            for (String sdData : dataFieldsArr) {
                double square = Math.pow((Integer.parseInt(sdData) - mean), 2);

                squareSum = squareSum + square;
            }

            stndrdDeviation = Math.sqrt(squareSum / (dataFieldsArr.length - 1));

            winningResult = new WinningResult();
            winningResult.setMean(mean);
            winningResult.setStandardDeviation(stndrdDeviation);
        }

        return winningResult;
    }
}
