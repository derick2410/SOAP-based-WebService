/*
 * (C) Derick Augustine Coutinho
 * This file is copyright to Derick.
 */
package edu.gmu.csd.bean;

import javax.faces.bean.ManagedBean;

/**
 * Class is used as a Managed Bean and also a POJO class which is used to set
 * and get the data.
 *
 * @author Derick Augustine Coutinho
 * @since 05/02/2015
 * @version 0.1
 */
@ManagedBean
public class WinningResult {

    private double mean;
    private double standardDeviation;

    public double getMean() {
        return mean;
    }

    public void setMean(double mean) {
        this.mean = mean;
    }

    public double getStandardDeviation() {
        return standardDeviation;
    }

    public void setStandardDeviation(double standardDeviation) {
        this.standardDeviation = standardDeviation;
    }
}
