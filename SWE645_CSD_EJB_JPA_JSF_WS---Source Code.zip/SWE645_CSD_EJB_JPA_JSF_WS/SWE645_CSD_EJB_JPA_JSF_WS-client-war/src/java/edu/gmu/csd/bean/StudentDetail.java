/*
 * (C) Derick Augustine Coutinho
 * This file is copyright to Derick.
 */
package edu.gmu.csd.bean;

import java.util.HashMap;
import java.util.Map;

/**
 * Class is a POJO class in which data is stored.
 *
 * @author Derick Augustine Coutinho
 * @since 05/02/2015
 * @version 0.1
 */
public class StudentDetail {

    private long studentid;
    private String firstname;
    private String lastname;
    private String streetaddress;
    private String zipcode;
    private String city;
    private String sstate;
    private String telnum;
    private String email;
    private String surveydate;
    private String likings;
    private String[] campusLike;
    private String interest;
    private String recomend;
    private String ename1;
    private String etel1;
    private String eemail1;
    private String ename2;
    private String etel2;
    private String eemail2;
    private String raffle;

    public long getStudentid() {
        return studentid;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getStreetaddress() {
        return streetaddress;
    }

    public String getZipcode() {
        return zipcode;
    }

    public String getCity() {
        return city;
    }

    public String getSstate() {
        return sstate;
    }

    public String getTelnum() {
        return telnum;
    }

    public String getEmail() {
        return email;
    }

    public String getSurveydate() {
        return surveydate;
    }

    public String getLikings() {
        return likings;
    }

    public String[] getCampusLike() {
        return campusLike;
    }

    public String getInterest() {
        return interest;
    }

    public String getRecomend() {
        return recomend;
    }

    public void setStudentid(long studentid) {
        this.studentid = studentid;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setStreetaddress(String streetaddress) {
        this.streetaddress = streetaddress;
    }

    public void setZipcode(String zipcode) {
        if (null != zipcode) {
            if (zipcode.length() == 5) {
                for (Map.Entry<String, String> entry : getZipCityStateMap().entrySet()) {
                    if (entry.getKey().equals(zipcode)) {
                        String[] cityState = entry.getValue().split("-");
                        city = cityState[0];
                        sstate = cityState[1];
                        break;
                    } else {
                        city = "";
                        sstate = "";
                    }
                }
            }
        }
        this.zipcode = zipcode;
    }

    public Map<String, String> getZipCityStateMap() {
        Map<String, String> zipCityState = new HashMap<String, String>();
        zipCityState.put("22312", "Alexandria-VA");
        zipCityState.put("22030", "Fairfax-VA");
        zipCityState.put("22301", "Tysons Corner-MD");
        zipCityState.put("20148", "Ashburn-VA");

        return zipCityState;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setSstate(String sstate) {
        this.sstate = sstate;
    }

    public void setTelnum(String telnum) {
        this.telnum = telnum;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSurveydate(String surveydate) {
        this.surveydate = surveydate;
    }

    public void setLikings(String likings) {
        this.likings = likings;
    }

    public void setCampusLike(String[] campusLike) {
        this.campusLike = campusLike;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public void setRecomend(String recomend) {
        this.recomend = recomend;
    }

    public void setEname1(String ename1) {
        this.ename1 = ename1;
    }

    public void setEtel1(String etel1) {
        this.etel1 = etel1;
    }

    public void setEemail1(String eemail1) {
        this.eemail1 = eemail1;
    }

    public void setEname2(String ename2) {
        this.ename2 = ename2;
    }

    public void setEtel2(String etel2) {
        this.etel2 = etel2;
    }

    public void setEemail2(String eemail2) {
        this.eemail2 = eemail2;
    }

    public String getEname1() {
        return ename1;
    }

    public String getEtel1() {
        return etel1;
    }

    public String getEemail1() {
        return eemail1;
    }

    public String getEname2() {
        return ename2;
    }

    public String getEtel2() {
        return etel2;
    }

    public String getEemail2() {
        return eemail2;
    }

    public String getRaffle() {
        return raffle;
    }

    public void setRaffle(String raffle) {
        this.raffle = raffle;
    }
}
